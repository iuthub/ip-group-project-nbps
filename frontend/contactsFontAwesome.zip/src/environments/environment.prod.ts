export const environment = {
  production: true, 
  serverUrl: "http://localhost:8000/api" //prod backend url
};
